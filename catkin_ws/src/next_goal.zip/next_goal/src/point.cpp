#include "point.h"

point::point()
{
    ros::NodeHandle nh;

    //publish
    goal_pub = nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal",10);
    //subscibe
    goal_sub = nh.subscribe("/move_base_simple/goal",10,&point::goal_callback,this);
    current_sub = nh.subscribe("/amcl_pose",10,&point::amcl_callback,this);
    //point
    node[0]={0.497762962173, -0.308064600171, 1};
    node[1]={2.45057215145, 0.0181094133518, 0.75};
    node[2]={2.9506921622, 1.34924363663, 0.65};
    node[3]={3.07424021866, 2.82286608539, 0.25};
    node[4]={1.52560869177, 3.65735450706, 0};
    node[5]={0.263203667222, 3.6882641403, 0};
    node[6]={-1.11006552549, 3.4655583391, -0.25};
    node[7]={-2.12430806264, 2.14179120734, 0.5};
    node[8]={-2.08565683185, 0.780913984384, 0.75};
    node[9]={-0.875144404987, -0.0622035756579, 1};
}

void point::goal_callback(const geometry_msgs::PoseStamped& msg)
{
    goal = msg;
    xp1 = goal.pose.position.x;
    yp1 = goal.pose.position.y;
    state = true;
}

void point::amcl_callback(const geometry_msgs::PoseWithCovarianceStamped& msg)
{
    amcl = msg;
    xp2 = amcl.pose.pose.position.x;
    yp2 = amcl.pose.pose.position.y;
}

float point::calcDistance()
{
    codist = (xp1-xp2)*(xp1-xp2)+(yp1-yp2)*(yp1-yp2);
    dist = sqrt(codist);
    std::cout<<"dist : "<<dist<<std::endl;
    return dist;
}

Node point::nextGoal()
{
    float max = 0;
    
    if(first_state == false)
    {
        for(int i=0; i<10; i++)
        {
            codistance = (node[i].x-amcl.pose.pose.position.x)*(node[i].x-amcl.pose.pose.position.x)+(node[i].y-amcl.pose.pose.position.y)*(node[i].y-amcl.pose.pose.position.y);
            distance = sqrt(codistance);
            if(distance > max)
            {
                max = distance;
                max_index = i;
            }
        }
        first_state = true;
        std::cout<<"GOOD"<<std::endl;
        return node[max_index];
    }
    else
    {
        std::cout<<"max_index : "<<max_index<<std::endl;
        max_index = max_index + 1;
        if(max_index > 9)
        {    
            max_index = 0;
            return node[max_index];
        }
        else if(max_index == 3)
        {
            max_index = 4;
            return node[max_index];
        }
        else
        {
           
            return node[max_index];
        }
    }
}

void point::pub_goal()
{
    Node nextnode;
 
    nextnode = nextGoal();

    next_goal.pose.position.x = nextnode.x;
    next_goal.pose.position.y = nextnode.y;

    next_goal.pose.orientation.w = node[max_index].w;
    next_goal.pose.orientation.z = sqrt(1-next_goal.pose.orientation.w*next_goal.pose.orientation.w);
 
    next_goal.header.frame_id = "map";
 
    goal_pub.publish(next_goal);
}

void point::isPub()
{
    std::cout<<"max_index : "<<max_index<<std::endl;
    if(state == true)
    {
        float d;
        d=calcDistance();
        if(d<=1.0)
        {
            pub_goal();
        }
        else
        {
            ;
        }
    }
    else
    {
        ;
    }
}

int main(int argc, char * argv[])
{
    ros::init(argc, argv, "point");
    ros::NodeHandle nh;
    ros::NodeHandle nh_priv("~");

    point p;

    ros::Rate  loop_rate(10);

    while(ros::ok())
    {
        p.isPub();
        loop_rate.sleep();
        ros::spinOnce();
    }

    ros::spin();
    return 0;
}
